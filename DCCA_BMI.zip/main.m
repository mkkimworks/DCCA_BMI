%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Title: Decoding kinematic information from primary motor cortical
%          ensemble activity using a deep canonical correlation analysis
%   Authors: M-K Kim; J-W Sohn; S-P Kim
%   E-mail: mkkim.works@gmail.com
%   Affiliation: Ulsan National Institute of Science and Technology (UNIST)
%   Copyright 2020. Authors All Rights Reserved.
%
%   Using a linear Kalman filter for demonstration
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


clear; clc; close all;

addpath('./DCCA')
addpath('./DCCA/deepnet')
addpath('./Decoders/');
addpath('./DrawPlot/');
load('./Dataset/monkey_data.mat');      % Dataset
load('./Dataset/DCCA_param.mat');       % example: trained DCCA parameter
load('./Dataset/LSTM_param');           % example: trained LSTM parameter
dim                         = size(TrX,2);
interp_len                  = 20;
TargetDegrees               = unique(Target);
Trial_ID                    = unique(TeID);
NumTargets                  = length(TargetDegrees);
LenTrials                   = length(Trial_ID);

% Linear CCA
lcca_prm                    = fcnCCA(TrZ, TrX);
TrLCCA_Z                    = lcca_prm.fcn.A(TrZ);
TeLCCA_Z                    = lcca_prm.fcn.A(TeZ);
TrLCCA_X                    = lcca_prm.fcn.B(TrX);
TeLCCA_X                    = lcca_prm.fcn.B(TeX);

% Deep CCA
NumOptRepeats               = 500;
dcca_prm                    = fcnDCCA(TrZ, TrX, NumOptRepeats, DCCA_param);
TrDCCA_Z                    = dcca_prm.fcn.A(TrZ);
TeDCCA_Z                    = dcca_prm.fcn.A(TeZ);
TrDCCA_X                    = dcca_prm.fcn.B(TrX);
TeDCCA_X                    = dcca_prm.fcn.B(TeX);

% Training Kalman filter
R_FR_KF                     = KFTraining(TrZ, TrX);
LCCA_KF                     = KFTraining(TrLCCA_Z, TrLCCA_X);
DCCA_KF                     = KFTraining(TrDCCA_Z, TrDCCA_X);

% Simulation
TargetInd                   = zeros(NumTargets,1);
vED                         = zeros(LenTrials, 3);
pED                         = zeros(LenTrials, 3);
T_phat_tmp                  = zeros(interp_len, dim-1, LenTrials, NumTargets);
R_phat_tmp                  = zeros(interp_len, dim-1, LenTrials, NumTargets);
L_phat_tmp                  = zeros(interp_len, dim-1, LenTrials, NumTargets);
D_phat_tmp                  = zeros(interp_len, dim-1, LenTrials, NumTargets);
for i = 1 : LenTrials
    targ_i                  = Target(i) == TargetDegrees;
    TargetInd(targ_i)       = TargetInd(targ_i) + 1;
    
    ind                     = Trial_ID(i) == TeID;
    vtrue                   = TeX(ind,1:end-1);
    ptrue                   = cumsum(vtrue);
    Z_R_FR                  = TeZ(ind,:);
    Z_LCCA                  = TeLCCA_Z(ind,:);
    Z_DCCA                  = TeDCCA_Z(ind,:);
    
    len                     = sum(ind);
    R_vhat                  = zeros(len, dim);
    L_vhat                  = zeros(len, dim);
    D_vhat                  = zeros(len, dim);
    for k = 1 : len
        [R_vhat(k,:), R_FR_KF] = KFpredict(Z_R_FR(k,:), R_FR_KF);
        [L_vhat(k,:), LCCA_KF] = KFpredict(Z_LCCA(k,:), LCCA_KF);
        [D_vhat(k,:), DCCA_KF] = KFpredict(Z_DCCA(k,:), DCCA_KF);
    end
    L_vhat                  = lcca_prm.fcn.invB(L_vhat);
    D_vhat                  = dcca_prm.fcn.invB(D_vhat); D_vhat = D_vhat(:,1:end-1);
    R_FR_KF                 = InitLKF(R_FR_KF);
    LCCA_KF                 = InitLKF(LCCA_KF);
    DCCA_KF                 = InitLKF(DCCA_KF);
    
    R_vhat                  = R_vhat(:,1:end-1);
    L_vhat                  = L_vhat(:,1:end-1);
    D_vhat                  = D_vhat(:,1:end-1);
    
    R_phat                  = cumsum(R_vhat);
    L_phat                  = cumsum(L_vhat);
    D_phat                  = cumsum(D_vhat);
    
    vED(i,:)                = [CalcED(R_vhat, vtrue) CalcED(L_vhat, vtrue) CalcED(D_vhat, vtrue)];
    pED(i,:)                = [CalcED(R_phat, ptrue) CalcED(L_phat, ptrue) CalcED(D_phat, ptrue)];
    
    T_phat_tmp(:,:,TargetInd(targ_i),targ_i)       = pchip(linspace(0, 1, len), ptrue', linspace(0, 1, interp_len))';
    R_phat_tmp(:,:,TargetInd(targ_i),targ_i)       = pchip(linspace(0, 1, len), R_phat', linspace(0, 1, interp_len))';
    L_phat_tmp(:,:,TargetInd(targ_i),targ_i)       = pchip(linspace(0, 1, len), L_phat', linspace(0, 1, interp_len))';
    D_phat_tmp(:,:,TargetInd(targ_i),targ_i)       = pchip(linspace(0, 1, len), D_phat', linspace(0, 1, interp_len))';
end

figure,
h1 = subplot(131); fcnErrorbar2D({T_phat_tmp, TargetInd},'color','k','handles',h1); hold(h1,'on'); fcnErrorbar2D({R_phat_tmp, TargetInd},'color','b','handles',h1, 'title','Raw FR'); 
h1 = subplot(132); fcnErrorbar2D({T_phat_tmp, TargetInd},'color','k','handles',h1); hold(h1,'on'); fcnErrorbar2D({L_phat_tmp, TargetInd},'color','m','handles',h1, 'title','LCCA'); 
h1 = subplot(133); fcnErrorbar2D({T_phat_tmp, TargetInd},'color','k','handles',h1); hold(h1,'on'); fcnErrorbar2D({D_phat_tmp, TargetInd},'color','r','handles',h1, 'title','DCCA'); 

figure, 
s1 = subplot(211); fcnErrorbar(vED,'xticklabel',{'Raw FR','LCCA','DCCA'},'ylabel', 'velocity error','handles',s1);
s2 = subplot(212); fcnErrorbar(pED,'xticklabel',{'Raw FR','LCCA','DCCA'},'ylabel', 'position error','handles',s2);




% Training LSTM
NumOptRepeats               = 1;
LSTM_R                      = fcnLSTM(TrZ, TrX, NumOptRepeats, lstm_param{1});
LSTM_L                      = fcnLSTM(TrLCCA_Z, TrLCCA_X, NumOptRepeats, lstm_param{2});
LSTM_D                      = fcnLSTM(TrDCCA_Z, TrDCCA_X, NumOptRepeats, lstm_param{3});

% Simulation
TargetInd                   = zeros(NumTargets,1);
vED                         = zeros(LenTrials, 3);
pED                         = zeros(LenTrials, 3);
T_phat_tmp                  = zeros(interp_len, dim-1, LenTrials, NumTargets);
R_phat_tmp                  = zeros(interp_len, dim-1, LenTrials, NumTargets);
L_phat_tmp                  = zeros(interp_len, dim-1, LenTrials, NumTargets);
D_phat_tmp                  = zeros(interp_len, dim-1, LenTrials, NumTargets);
for i = 1 : LenTrials
    targ_i                  = Target(i) == TargetDegrees;
    TargetInd(targ_i)       = TargetInd(targ_i) + 1;
    
    ind                     = Trial_ID(i) == TeID;
    vtrue                   = TeX(ind,1:end-1);
    ptrue                   = cumsum(vtrue);
    Z_R_FR                  = TeZ(ind,:);
    Z_LCCA                  = TeLCCA_Z(ind,:);
    Z_DCCA                  = TeDCCA_Z(ind,:);
    
    len                     = sum(ind);
    R_vhat                  = zeros(len, dim);
    L_vhat                  = zeros(len, dim);
    D_vhat                  = zeros(len, dim);
    for k = 1 : len
        R_vhat(k,:)         = double(predict(LSTM_R, Z_R_FR(k,:)'));
        L_vhat(k,:)         = double(predict(LSTM_L, Z_LCCA(k,:)'));
        D_vhat(k,:)         = double(predict(LSTM_D, Z_DCCA(k,:)'));
    end
    L_vhat                  = lcca_prm.fcn.invB(L_vhat);
    D_vhat                  = dcca_prm.fcn.invB(D_vhat); D_vhat = D_vhat(:,1:end-1);
    
    R_vhat                  = R_vhat(:,1:end-1);
    L_vhat                  = L_vhat(:,1:end-1);
    D_vhat                  = D_vhat(:,1:end-1);
    
    R_phat                  = cumsum(R_vhat);
    L_phat                  = cumsum(L_vhat);
    D_phat                  = cumsum(D_vhat);
    
    vED(i,:)                = [CalcED(R_vhat, vtrue) CalcED(L_vhat, vtrue) CalcED(D_vhat, vtrue)];
    pED(i,:)                = [CalcED(R_phat, ptrue) CalcED(L_phat, ptrue) CalcED(D_phat, ptrue)];
    
    T_phat_tmp(:,:,TargetInd(targ_i),targ_i)       = pchip(linspace(0, 1, len), ptrue', linspace(0, 1, interp_len))';
    R_phat_tmp(:,:,TargetInd(targ_i),targ_i)       = pchip(linspace(0, 1, len), R_phat', linspace(0, 1, interp_len))';
    L_phat_tmp(:,:,TargetInd(targ_i),targ_i)       = pchip(linspace(0, 1, len), L_phat', linspace(0, 1, interp_len))';
    D_phat_tmp(:,:,TargetInd(targ_i),targ_i)       = pchip(linspace(0, 1, len), D_phat', linspace(0, 1, interp_len))';
end

figure,
h1 = subplot(131); fcnErrorbar2D({T_phat_tmp, TargetInd},'color','k','handles',h1); hold(h1,'on'); fcnErrorbar2D({R_phat_tmp, TargetInd},'color','b','handles',h1, 'title','Raw FR'); 
h1 = subplot(132); fcnErrorbar2D({T_phat_tmp, TargetInd},'color','k','handles',h1); hold(h1,'on'); fcnErrorbar2D({L_phat_tmp, TargetInd},'color','m','handles',h1, 'title','LCCA'); 
h1 = subplot(133); fcnErrorbar2D({T_phat_tmp, TargetInd},'color','k','handles',h1); hold(h1,'on'); fcnErrorbar2D({D_phat_tmp, TargetInd},'color','r','handles',h1, 'title','DCCA'); 

figure, 
s1 = subplot(211); fcnErrorbar(vED,'xticklabel',{'Raw FR','LCCA','DCCA'},'ylabel', 'velocity error','handles',s1);
s2 = subplot(212); fcnErrorbar(pED,'xticklabel',{'Raw FR','LCCA','DCCA'},'ylabel', 'position error','handles',s2);